<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sms_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
 // echo "Connected successfully";
}

if(isset($_POST['submit'])){

  if (!empty($_POST['name'])  && !empty($_POST['cno']) && !empty($_POST['nic']) && !empty($_POST['email']) 
    && !empty($_POST['psw']) ) {


      $img = $_FILES['img']['name'];
      // $file_size =$_FILES['img']['size'];
      $file_tmp =$_FILES['img']['tmp_name'];
      $file_type=$_FILES['img']['type'];
      $file_ext = pathinfo($_FILES['img']['name'], PATHINFO_EXTENSION);
      $extensions= array("jpeg","jpg","png");
      
      if(in_array($file_ext,$extensions) === false){
        $msg = "<b>Error: </b>Extension not allowed, please choose a JPG, JPEG or PNG file..";
        echo  $msg;
        exit;
      }
         move_uploaded_file($file_tmp,"img/".$img);
       
 


 $name = $_POST["name"];
 $contactno = $_POST["cno"];
 $cnic = $_POST["nic"];
  $email = $_POST["email"];
 $password= $_POST["psw"];
  // $image = $_POST["img"];


$sql = "SELECT email FROM employee WHERE  email='$email'"; 
$result = $conn-> query($sql);
$row = $result-> fetch_assoc();
if (!empty($row)) {
  echo " Email Already Exist";
}

else{
 $query = "INSERT INTO employee (name, phone, cnic, email, password, image)  
          values('$name', '$contactno', '$cnic',  '$email',  '$password',  '$img' )";

    $run = mysqli_query($conn, $query) or die(mysql_error());
       
    if($run){
      // echo "Form Submited Successfully";
    }
    else {
      echo "Form Not Submited";
    }
  }
}
    else {
      echo "All Fields Required";
    }
  } 

?>  

<!DOCTYPE html>
<html>
<style>
 body {
   background-image: url("9.jpg");
    background-repeat: no-repeat;
  background-size: 100%;
}
body {font-family: Arial, Helvetica, sans-serif;
  background-color: #22c1c3;
}
* {box-sizing: border-box}


input[type=text], input[type=password] {
  width: 100%;
  padding: 12px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

button {
  background-color: #3d4769;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}
 .signupbtn {
  float: left;
  width: 100%;
}
.container {
  padding: 16px;
}

.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

, .signupbtn {
     width: 100%;
  }
}
</style>
<body>

<form action="" method="post" enctype="multipart/form-data" style="border:1px solid #ccc">
  <div class="container">
    <h1 align="center" style="text-shadow: 3px 3px 6px burlywood;">Right Ways System</h1>
    <h2>Sign Up</h2>
    <p>Please fill in this form to create an account.</p>
    <hr>

    <label for=""><b>Student Name*</b></label>
    <input type="text" name="name" required placeholder="Enter Your Full Name">

    <label for=""><b>Contact No*</b></label>
    <input type="text" name="cno" required placeholder="Enter Your Contact No">

    <label for=""><b>CNIC*</b></label>
    <input type="text" name="nic" required placeholder="Enter Your Cnic">

     <label for=""><b>E-Mail*</b></label>
    <input type="text" name="email" required placeholder="Enter Your E-Mail">

    <label for=""><b>Passsword*</b></label>
    <input type="password" name="psw" required placeholder="Enter Your Passsword">

      <label for=""><b>Image*</b></label>
    <input type= file name="img" style="width: 50%;  font-size : 13px;"></b></p> 

<br>
    <p>I have already an account <a href="index2.php" style="color:#1e222f">Login</a></p>

    <div class="clearfix">
      <button type="submit" name="submit" class="signupbtn">Sign Up</button>
    </div>
  </div>
</form>
</body>
</html>
 
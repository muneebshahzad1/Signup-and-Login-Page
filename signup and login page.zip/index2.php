
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sms_db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
else{
 // echo "Connected successfully";
}
if (isset($_POST['submit'])) {
        $email = $_POST['uname'];

        $password = $_POST['psw'];

    
// sql to delete a record
$sql = "SELECT name, phone, cnic, email, password, image FROM employee WHERE email='$email'";
$result = $conn->query($sql);
if ($row = $result->fetch_assoc()) {
  if ($email == $row["email"] && $password == $row["password"]) {
    $name = $row["name"];
    $phone = $row["phone"];
    $cnic = $row["cnic"];
    $email = $row["email"];
    $password = $row["password"];
    $image = $row["image"];
?>
 <!DOCTYPE html>
 <html>
 <head>
  <style>
   body {
   background-image: url("9.jpg");
    background-repeat: no-repeat;
  background-size: 100%;
  text-align: center;
}
  h1 {
  text-shadow: 2px 2px 4px burlywood;
text-align: center;
font-size: 40px;
}
table th {
   padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #9a8744;
  color: #373634;
   font-size: 17px;
}
table td {
   padding-top: 10px;
  padding-bottom: 14px;
  text-align: center;
  background-color: #dfd8c8;
  color:#524834;
  font-weight: bold;
  font-size: 19px;

}

}
.button5 {
  background-color: #4CAF50;
  border: none;
  padding: 16px 32px;
  text-align: center;
  display: inline-block;
  font-size: 38px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}
  .button5 {
  background-color:  #9a8744;
  color: black;
  border: 3px solid #555555;
  text-align: center;
}

.button5:hover {
  background-color: #d42424;
  color: 
}
.button5 {width: 130px;
height: 50px;
font-size: 20px;
}

</style>
 </head>
 <body>
<h1>Welcome To Dashboard </h1>
<br>
<br>
<table border="1" align="center" cellpadding="10px">
 <tr>
 <th colspan="1"> Name*</th>
 <th colspan="1"> CNIC*</th>
 <th colspan="1">Contact No*</th>
 <th colspan="1">Image*</th>
 </tr>
 <tr>
   <td><?php echo  $name;?></td>
    <td><?php echo  $cnic;?></td>
     <td><?php echo  $phone;?></td>
   <td><?php echo "<img src ='img/$image' height='160px' width='150px'>";?></td>
 </tr>
 </table>
 <br>
<button class="button5"><a href="index2.php" >Logout</a></button>
 </body>
 </html>




 <?php
exit;
  }else{
    echo "<div class='alert alert-danger'>Incorrect email or password.</div>";
  }
  
}
 else {
  echo "Error: Email Not found. </div>";
}
   
}


?>


<!DOCTYPE html>
<html>
<head>

<style>
body {font-family: Arial, Helvetica, sans-serif;
background-color: #22c1c3;
}
 body {
   background-image: url("9.jpg");
    background-repeat: no-repeat;
  background-size: 100%;
}

form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #3d4769;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}
h2{

   text-shadow: 2px 2px 4px burlywood;
   text-align: center;
   font-size: 32px;

}

@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<h2>Login To Right Ways System</h2>
<br>

<form action=""  method="post">

  <div class="container">
    <label for="uname"><b>E-Mail*</b></label>
    <input type="text"  name="uname" required>

    <label for="psw"><b>Password*</b></label>
    <input type="password" name="psw" required>
        
    <button type="submit" name="submit" >Login</button>
   
  </div>
  <div class="container" style="background-color:#f1f1f1">
  </div>
</form>

</body>
</html>
